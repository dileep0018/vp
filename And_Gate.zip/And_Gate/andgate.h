#include <systemc.h>

SC_MODULE(AndGate)
{
	sc_in<bool> a;
	sc_in<bool> b;
	sc_out<bool> out;
	
	void andOperation(){
		out.write( a.read() && b.read());
	}
	
	SC_CTOR(AndGate){
		SC_METHOD(andOperation);
		sensitive << a << b;	
	}
	
};
