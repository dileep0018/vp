#include <systemc.h>

#include "andgate.h"
#include "monitor.h"
#include "driver.h"

int sc_main(int argc, char* argv[])
{
	sc_signal<bool> a, b, out;
	
	
	AndGate andGate("andGate");
	andGate.a(a);
	andGate.b(b);
	andGate.out(out);
	
	MonitorAndGate monitor("monitor");
	monitor.out(out);
	monitor.a(a);
	monitor.b(b);
	
	driverAndGate driver("driver");
	driver.a(a);
	driver.b(b);
	
	sc_trace_file *Tf;
	Tf = sc_create_vcd_trace_file("traces");
	sc_trace(Tf, a, "a");
	sc_trace(Tf, b, "b");
	sc_trace(Tf, out, "out");
	sc_start(20, SC_NS);
	sc_close_vcd_trace_file(Tf);
	
	return 0;
}
