#include <systemc.h>

SC_MODULE(MonitorAndGate)
{
	sc_in<bool>a, b, out;
	
	void monitor(){
		cout<< "Inputs: "<<a <<b <<" And Gate Otuput: " << out <<endl;
	}
	
	SC_CTOR(MonitorAndGate){
	SC_METHOD(monitor);
	sensitive << out <<a <<b;	
	}
	
};
